// Superdh.h : main header file for the SUPERDH application
//

#if !defined(AFX_SUPERDH_H__D6948766_E434_4C06_BE7E_999CDCF50EE9__INCLUDED_)
#define AFX_SUPERDH_H__D6948766_E434_4C06_BE7E_999CDCF50EE9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSuperdhApp:
// See Superdh.cpp for the implementation of this class
//

class CSuperdhApp : public CWinApp
{
public:
	CSuperdhApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuperdhApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSuperdhApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUPERDH_H__D6948766_E434_4C06_BE7E_999CDCF50EE9__INCLUDED_)
