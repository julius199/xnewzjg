// WSDSetDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Superdh.h"
#include "WSDSetDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWSDSetDlg dialog


CWSDSetDlg::CWSDSetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWSDSetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWSDSetDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CWSDSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWSDSetDlg)
	DDX_Control(pDX, IDC_COM_JKPOINT, m_jkpoint);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWSDSetDlg, CDialog)
	//{{AFX_MSG_MAP(CWSDSetDlg)
	ON_BN_CLICKED(IDC_BUT_SAVE, OnButSave)
	ON_BN_CLICKED(IDC_BUT_CALL, OnButCall)
	ON_CBN_SELCHANGE(IDC_COM_JKPOINT, OnSelchangeComJkpoint)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWSDSetDlg message handlers

BOOL CWSDSetDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString Sjkp11;

   Sjkp11.Format(" %d ",jkpoint);

   // TODO: Add extra initialization here
	SetDlgItemText(IDC_STA_TCURR,Sjkp11);
	m_jkpoint.AddString("�����豸��1");
	m_jkpoint.AddString("�����豸��2");
	m_jkpoint.AddString("�����豸��3");
	m_jkpoint.AddString("35KV������1");
	m_jkpoint.AddString("35KV������2");
	m_jkpoint.AddString("35KV������3");

m_jkpoint.SetCurSel(0);

ctlkdg11=0;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CWSDSetDlg::OnButSave() 
{
	// TODO: Add your control notification handler code here
		char cWorkDir[256];
		 char ww[1];
		 	char buf[256];

	CStdioFile wsdbjFile;
	GetCurrentDirectory(256, cWorkDir);
	int jkpk11,mh11;
    
	int kwdsx11,kwdxx11,ksdsx11,ksdxx11;

    CString avsunrec11,saoft11,scom_wsdp;
    CString wsdsxpa11,wsdsxpa12;

    CString wdsx11,wdsx12,wdxx11,wdxx12;
	CString sdsx11,sdsx12,sdxx11,sdxx12;

   // CTime saotime11 = CTime::GetCurrentTime();
//	saoft11= saotime11.Format(_T("%Y_%m_%d_%H_%M_%S"));

	GetDlgItemText(IDC_COM_JKPOINT,scom_wsdp);

	GetDlgItemText(IDC_EDIT_WDSX11,wdsx11);
	GetDlgItemText(IDC_EDIT_WDSX12,wdsx12);

	GetDlgItemText(IDC_EDIT_WDXX11,wdxx11);
	GetDlgItemText(IDC_EDIT_WDXX12,wdxx12);

	GetDlgItemText(IDC_EDIT_SDSX11,sdsx11);
	GetDlgItemText(IDC_EDIT_SDSX12,sdsx12);

	GetDlgItemText(IDC_EDIT_SDXX11,sdxx11);
	GetDlgItemText(IDC_EDIT_SDXX12,sdxx12);

if ((atoi(wdsx11)>0) &&  (atoi(wdsx11)<80) &&  (atoi(wdsx12)<10) &&  (atoi(wdsx12)>=0) )
{
	mh11=1;
}
else
{
AfxMessageBox("�¶� error!");
return;
}

if ((atoi(wdxx11)>-20) &&  (atoi(wdxx11)<50) &&  (atoi(wdxx12)<10) &&  (atoi(wdxx12)>=0) )
{
	mh11=1;
}
else
{
AfxMessageBox("�¶� error!");
return;
}

if ((atoi(sdsx11)>0) &&  (atoi(sdsx11)<120) &&  (atoi(sdsx12)<10) &&  (atoi(sdsx12)>=0) )
{
	mh11=1;
}
else
{
AfxMessageBox("ʪ�� error!");
return;
}
if ((atoi(sdxx11)>0) &&  (atoi(sdxx11)<70) &&  (atoi(sdxx12)<10) &&  (atoi(sdxx12)>=0) )
{
	mh11=1;
}
else
{
AfxMessageBox("ʪ�� error!");
return;
}

if (scom_wsdp=="�����豸��1")
{
jkpk11=1;
	ww[0]='a';
}

if (scom_wsdp=="�����豸��2")
{
jkpk11=2;
	ww[0]='b';
}

if (scom_wsdp=="�����豸��3")
{
jkpk11=3;
	ww[0]='c';
}
if (scom_wsdp=="35KV������1")
{
jkpk11=4;
	ww[0]='d';
}

if (scom_wsdp=="35KV������2")
{
jkpk11=5;
	ww[0]='e';
}

if (scom_wsdp=="35KV������3")
{
jkpk11=6;
	ww[0]='f';
}
jkpoint=jkpk11;

	  wsdsxpa11.Format("%s\\wsdpara\\wsdsx%d.dsun", cWorkDir, jkpk11);
	  
	//  AfxMessageBox(wsdsxpa11);

	if (wsdbjFile.Open(wsdsxpa11, CFile::modeCreate|CFile::modeWrite) == FALSE)
	{
	 AfxMessageBox("create wsdsetfile error");
		return;
	}
	sprintf(buf,"$C\r\n");
					wsdbjFile.WriteString(buf);
             //   sprintf(buf,"%s\r\n",ww);		
		    //	wsdbjFile.WriteString(buf);
	                sprintf(buf,"%s\r\n",wdsx11);
					wsdbjFile.WriteString(buf);
					sprintf(buf,"%s\r\n",wdsx12);
					wsdbjFile.WriteString(buf);
       
					kwdsx11=atoi(wdsx11)*10+atoi(wdsx12);

                   sprintf(buf,"%s\r\n",wdxx11);
					wsdbjFile.WriteString(buf);
					sprintf(buf,"%s\r\n",wdxx12);
					wsdbjFile.WriteString(buf);
	         
					kwdxx11=atoi(wdxx11)*10+atoi(wdxx12);

                    sprintf(buf,"%s\r\n",sdsx11);
					wsdbjFile.WriteString(buf);
					sprintf(buf,"%s\r\n",sdsx12);
					wsdbjFile.WriteString(buf);

				    ksdsx11=atoi(sdsx11)*10+atoi(sdsx12);


                    sprintf(buf,"%s\r\n",sdxx11);
					wsdbjFile.WriteString(buf);
					sprintf(buf,"%s\r\n",sdxx12);
					wsdbjFile.WriteString(buf);

				ksdxx11=atoi(sdxx11)*10+atoi(sdxx12);

				switch(jkpk11)
	{
	   case 1:
		   pwdsx11=kwdsx11;
	       pwdxx11=kwdxx11;
           psdsx11=ksdsx11;
	       psdxx11=ksdxx11;

		break;

       case 2:
		   pwdsx21=kwdsx11;
	       pwdxx21=kwdxx11;
           psdsx21=ksdsx11;
	       psdxx21=ksdxx11;

		break;
       case 3:

		   pwdsx31=kwdsx11;
	       pwdxx31=kwdxx11;
           psdsx31=ksdsx11;
	       psdxx31=ksdxx11;

		break;

		case 4:

		   pwdsx41=kwdsx11;
	       pwdxx41=kwdxx11;
           psdsx41=ksdsx11;
	       psdxx41=ksdxx11;

		break;

	   case 5:

		   pwdsx51=kwdsx11;
	       pwdxx51=kwdxx11;
           psdsx51=ksdsx11;
	       psdxx51=ksdxx11;

		break;
       case 6:

		   pwdsx61=kwdsx11;
	       pwdxx61=kwdxx11;
           psdsx61=ksdsx11;
	       psdxx61=ksdxx11;

		break;

	   default:
		   break;

				}

ctlkdg11=1;


	wsdbjFile.Close();
    AfxMessageBox("����ɹ�!");


}

void CWSDSetDlg::OnButCall() 
{
	// TODO: Add your control notification handler code here
			char cWorkDir[256];
		 char ww[1];
		 	char buf[256];

	CStdioFile wsdbjFile;
	GetCurrentDirectory(256, cWorkDir);
	int jkpk11,mh11;

    CString avsunrec11,saoft11,scom_wsdp;
    CString wsdsxpa11,wsdsxpa12;

    CString wdsx11,wdsx12,wdxx11,wdxx12;
	CString sdsx11,sdsx12,sdxx11,sdxx12;

   // CTime saotime11 = CTime::GetCurrentTime();
//	saoft11= saotime11.Format(_T("%Y_%m_%d_%H_%M_%S"));


	GetDlgItemText(IDC_COM_JKPOINT,scom_wsdp);

if (scom_wsdp=="�����豸��1")
{
jkpk11=1;
	ww[0]='a';
}

if (scom_wsdp=="�����豸��2")
{
jkpk11=2;
	ww[0]='b';
}

if (scom_wsdp=="�����豸��3")
{
jkpk11=3;
	ww[0]='c';
}
if (scom_wsdp=="35KV������1")
{
jkpk11=4;
	ww[0]='d';
}

if (scom_wsdp=="35KV������2")
{
jkpk11=5;
	ww[0]='e';
}

if (scom_wsdp=="35KV������3")
{
jkpk11=6;
	ww[0]='f';
}

	  wsdsxpa11.Format("%s\\wsdpara\\wsdsx%d.dsun", cWorkDir, jkpk11);
	  
	//  AfxMessageBox(wsdsxpa11);

	if (wsdbjFile.Open(wsdsxpa11, CFile::modeRead) == FALSE)
	{
	 AfxMessageBox("����ʪ�ȱ�����,����������ʪ��!");
		return;
	}

    int jj11=0;

	while (wsdbjFile.ReadString(buf,256))
	{
jj11++;
if (jj11==2)
{
	wdsx11=buf;


	wdsx11=wdsx11.Left(wdsx11.GetLength()-2);

	SetDlgItemText(IDC_EDIT_WDSX11,wdsx11);
}
if (jj11==3)
{
	wdsx12=buf;

	wdsx12=wdsx12.Left(wdsx12.GetLength()-2);

	SetDlgItemText(IDC_EDIT_WDSX12,wdsx12);
}
if (jj11==4)
{
	wdxx11=buf;
	
	wdxx11=wdxx11.Left(wdxx11.GetLength()-2);

	SetDlgItemText(IDC_EDIT_WDXX11,wdxx11);
}

if (jj11==5)
{
	wdxx12=buf;
	wdxx12=wdxx12.Left(wdxx12.GetLength()-2);


	SetDlgItemText(IDC_EDIT_WDXX12,wdxx12);
}

if (jj11==6)
{
	sdsx11=buf;
	
	sdsx11=sdsx11.Left(sdsx11.GetLength()-2);

	SetDlgItemText(IDC_EDIT_SDSX11,sdsx11);
}
if (jj11==7)
{
	sdsx12=buf;

	sdsx12=sdsx12.Left(sdsx12.GetLength()-2);

	SetDlgItemText(IDC_EDIT_SDSX12,sdsx12);
}
if (jj11==8)
{
	sdxx11=buf;
	
	sdxx11=sdxx11.Left(sdxx11.GetLength()-2);

	SetDlgItemText(IDC_EDIT_SDXX11,sdxx11);
}

if (jj11==9)
{
	sdxx12=buf;
		
	sdxx12=sdxx12.Left(sdxx12.GetLength()-2);

	SetDlgItemText(IDC_EDIT_SDXX12,sdxx12);
}


	}


	wsdbjFile.Close();

 
}

void CWSDSetDlg::OnSelchangeComJkpoint() 
{
	// TODO: Add your control notification handler code here
//	iSelServer = m_ServerCtrl.GetCurSel() - 1;

	SetDlgItemText(IDC_EDIT_SDSX11,"");	
	SetDlgItemText(IDC_EDIT_SDSX12,"");
	SetDlgItemText(IDC_EDIT_SDXX11,"");	
	SetDlgItemText(IDC_EDIT_SDXX12,"");

	SetDlgItemText(IDC_EDIT_WDSX11,"");	
	SetDlgItemText(IDC_EDIT_WDSX12,"");
	SetDlgItemText(IDC_EDIT_WDXX11,"");	
	SetDlgItemText(IDC_EDIT_WDXX12,"");


}
