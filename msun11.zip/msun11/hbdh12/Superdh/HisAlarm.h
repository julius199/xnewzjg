#if !defined(AFX_HISALARM_H__D5DAF55A_83B0_4659_9371_2DD0EC4691A0__INCLUDED_)
#define AFX_HISALARM_H__D5DAF55A_83B0_4659_9371_2DD0EC4691A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HisAlarm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHisAlarm dialog

class CHisAlarm : public CDialog
{
// Construction
public:
	CHisAlarm(CWnd* pParent = NULL);   // standard constructor
public:
	void amdisplay(int uu11);
		long kf11;
	int kf12;
    CString wdsd11;
    CString wdsd12;
    CStdioFile wsdbjFile;
// Dialog Data
	//{{AFX_DATA(CHisAlarm)
	enum { IDD = IDD_DLG_HALARM };
	COleDateTime	m_btkdate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHisAlarm)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHisAlarm)
	virtual BOOL OnInitDialog();
	afx_msg void OnButBjjl();
	afx_msg void OnButMkdata();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISALARM_H__D5DAF55A_83B0_4659_9371_2DD0EC4691A0__INCLUDED_)
