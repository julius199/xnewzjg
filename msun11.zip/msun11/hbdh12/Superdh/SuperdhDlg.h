// SuperdhDlg.h : header file
//

#if !defined(AFX_SUPERDHDLG_H__9DF91E4B_9727_4D66_84FE_AF4FA7FE14AB__INCLUDED_)
#define AFX_SUPERDHDLG_H__9DF91E4B_9727_4D66_84FE_AF4FA7FE14AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//=========================
#include "Comm.h"
#include "GfxOutBarCtrl.h"

#define IDC_LST_MENU	WM_USER + 1000
/////////////////////////////////////////////////////////////////////////////
// CSuperdhDlg dialog

static CString DayOfWeek[] = {
   "������",
   "����һ",   
   "���ڶ�",
   "������",
   "������", 
   "������", 
   "������"
};


class CSuperdhDlg : public CDialog
{
// Construction

public:


	CComm m_comm1,m_comm2,m_comm3;
	unsigned char m_cCmdBuf[8];

	 unsigned char m_cComrcv1[12];
    unsigned char m_cComrcv2[12];
	unsigned char m_cComrcv3[12];

	unsigned char m_cRcvData1[12];
    unsigned char m_cRcvData2[12];
    unsigned char m_cRcvData3[12];


public:
	void ZxydelFile();
	int bkctlf11;
	void StxTime();
	int dkfilect11;
	void zkpiniRR11();
	void KdtOpenFile();
	void KtkOpenFile();
	int kctlcout12;
	int kctlcout11;
	void KSaveFile();
	void TScan12();
	void F_IniTreeall();
	CFont	m_fontText;
	HBRUSH	m_hBrushBK;
	
	HBRUSH	m_wBrushBK;

	int fsfxseq;
	int fsfxsctl;
	void sendfs11();
	void readtwsd(int pp11);

	int pwdxx11;
	int pwdsx11;
	int pwdxx21;
	int pwdsx21;
    int pwdxx31;
	int pwdsx31;
	int pwdxx41;
	int pwdsx41;
    int pwdxx51;
	int pwdsx51;
	int pwdxx61;
	int pwdsx61;

	int psdxx11;
	int psdsx11;
	int psdxx21;
	int psdsx21;
    int psdxx31;
	int psdsx31;
	int psdxx41;
	int psdsx41;
    int psdxx51;
	int psdsx51;
	int psdxx61;
	int psdsx61;

	COleDateTime m_curTime;

	int jrecount11;
	CString wsdrec11;
	CString wxfxrec11;
	CString walarmrec11;
	void sendfx11();
	void xiniwqq();
	BOOL m_schktime;
	void TScan11();
	int sendseq;
	void ggsendwsd(int gadd);
	void sendwd11();
	void OnCommRxchar(WPARAM wParam, LPARAM lParam);
	void OnKKCommRxchar(WPARAM wParam, LPARAM lParam);
	CSuperdhDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSuperdhDlg)
	enum { IDD = IDD_SUPERDH_DIALOG };
	CTreeCtrl	m_kswtp11;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuperdhDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
		int ComRecvDataLen1;
	int ComRecvDataLen2;
	int ComRecvDataLen3;

    	BYTE m_RevBuf1;
	BYTE m_RevBuf2;
	BYTE m_RevBuf3;

	HICON m_hIcon;

	CGfxOutBarCtrl	wndBar;
	CImageList		imaLarge, imaSmall;
  CToolBar    m_wndToolBar;

	// Generated message map functions
	//{{AFX_MSG(CSuperdhDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButDhsend();
	afx_msg void OnButDhkw11();
	afx_msg void OnButDhkw12();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButStop();
	afx_msg void OnButWyexit();
	afx_msg void OnWsdbjset();
	afx_msg void OnWzsexit();
	afx_msg void OnWzsabt();
	afx_msg void OnDblclkTreeKxw11(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnHisdata();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnAlarmdata();
	//}}AFX_MSG

	afx_msg long OnOutbarNotify(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUPERDHDLG_H__9DF91E4B_9727_4D66_84FE_AF4FA7FE14AB__INCLUDED_)
