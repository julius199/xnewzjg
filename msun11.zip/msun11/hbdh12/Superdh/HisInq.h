#if !defined(AFX_HISINQ_H__50617DBB_FE8E_4795_902F_647DBB22524C__INCLUDED_)
#define AFX_HISINQ_H__50617DBB_FE8E_4795_902F_647DBB22524C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HisInq.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHisInq dialog

class CHisInq : public CDialog
{
// Construction
public:
	void zkdisplay(int uu11);
	long kf11;
	int kf12;
    CString wdsd11;
    CString wdsd12;
    CStdioFile wsdbjFile;
	CHisInq(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CHisInq)
	enum { IDD = IDD_DLG_WHIS };
	COleDateTime	m_ctHisDate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHisInq)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHisInq)
	afx_msg void OnButFsfx();
	afx_msg void OnButWdsd();
	virtual BOOL OnInitDialog();
	afx_msg void OnButKwh11();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISINQ_H__50617DBB_FE8E_4795_902F_647DBB22524C__INCLUDED_)
