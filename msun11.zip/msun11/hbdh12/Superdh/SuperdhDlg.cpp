// SuperdhDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Superdh.h"
#include "SuperdhDlg.h"
#include "WSDSetDlg.h"
#include "HisInq.h"
#include "HisAlarm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CString jkparea[10];

static unsigned char auchCRCHi[] = {
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
	0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
	0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
	0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
	0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
	0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
	0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
	0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
	0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
	0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
	0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
	0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
	0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
	0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
	0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
	0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
	} ;

/* CRC��λ�ֽ�ֵ��*/
static unsigned char auchCRCLo[] = {
	0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06,
	0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD,
	0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
	0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A,
	0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4,
	0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
	0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3,
	0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4,
	0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
	0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29,
	0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED,
	0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
	0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60,
	0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67,
	0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
	0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68,
	0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E,
	0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
	0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71,
	0x70, 0xB0, 0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92,
	0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
	0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B,
	0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B,
	0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
	0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42,
	0x43, 0x83, 0x41, 0x81, 0x80, 0x40
	};

	unsigned char CRCHi=0xFF;
	unsigned char CRCLo=0xFF;
/*****CRCУ�����************************************************************


******************************************************************************/
void CRC16(unsigned char *puchMsg, unsigned char usDataLen)
{
	unsigned char uIndex;
CRCHi=0xFF;
CRCLo=0xFF;
//	unsigned char CRCHi=0xFF;
//	unsigned char CRCLo=0xFF;
	while (usDataLen--) /* ������Ϣ������ */
	{
		uIndex=CRCHi^*puchMsg++; /* ����CRC *///��λ�������
		CRCHi=CRCLo^auchCRCHi[uIndex];
		CRCLo=auchCRCLo[uIndex];
	}

//	return(CRCHi<<8|CRCLo);	
}

 CStdioFile sunrec11,sunalarm11,sunrec12;


HWND g_hwnd=0;

UINT  Beeper(LPVOID pParam)
{
/*
	while(true)
	{
		Beep(800,500);
		Beep(1000,500);
		Beep(800,500);
		Beep(1000,500);
		if(WaitForSingleObject(hVideoBeeper,1000) == WAIT_OBJECT_0)
		{
			ResetEvent(hVideoBeeper);
			hBeepThread = NULL;
			return FALSE;
		}
	}
*/
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperdhDlg dialog

CSuperdhDlg::CSuperdhDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSuperdhDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSuperdhDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
		m_hBrushBK = CreateSolidBrush(RGB(192,192,192));
	m_wBrushBK = CreateSolidBrush(RGB(83,166,166));

	m_fontText.CreatePointFont(110,"����");

}

void CSuperdhDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSuperdhDlg)
	DDX_Control(pDX, IDC_TREE_KXW11, m_kswtp11);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSuperdhDlg, CDialog)
	//{{AFX_MSG_MAP(CSuperdhDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUT_DHSEND, OnButDhsend)
	ON_BN_CLICKED(IDC_BUT_DHKW11, OnButDhkw11)
	ON_BN_CLICKED(IDC_BUT_DHKW12, OnButDhkw12)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUT_STOP, OnButStop)
	ON_BN_CLICKED(IDC_BUT_WYEXIT, OnButWyexit)
	ON_COMMAND(IDM_WSDBJSET, OnWsdbjset)
	ON_COMMAND(IDM_WZSEXIT, OnWzsexit)
	ON_COMMAND(IDM_WZSABT, OnWzsabt)
	ON_NOTIFY(NM_DBLCLK, IDC_TREE_KXW11, OnDblclkTreeKxw11)
	ON_COMMAND(IDM_HISDATA, OnHisdata)
	ON_WM_CTLCOLOR()
	ON_COMMAND(IDM_ALARMDATA, OnAlarmdata)
	//}}AFX_MSG_MAP

ON_MESSAGE(WM_COMM_RXCHAR, OnCommRxchar)
ON_MESSAGE(WM_COMM_KKRXCHAR, OnKKCommRxchar)
ON_MESSAGE(WM_OUTBAR_NOTIFY, OnOutbarNotify)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperdhDlg message handlers

BOOL CSuperdhDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	   g_hwnd = GetSafeHwnd();
sendseq=0;
fsfxseq=0;
fsfxsctl=0;

bkctlf11=0;

kctlcout11=360;
kctlcout12=360;

dkfilect11=0;

		if (!m_wndToolBar.CreateEx( this,TBSTYLE_FLAT ,  WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP |CBRS_TOOLTIPS/*| CBRS_GRIPPER*/ | CBRS_TOOLTIPS,
        CRect(3, 3, 0, 0)) ||	!m_wndToolBar.LoadToolBar(IDR_STOOLMBAR) )
    {
        TRACE0("failed to create toolbar\n");
        return FALSE;
    }

    CSize btnSize(59, 59), imgSize(33, 38); 
    
    m_wndToolBar.SetSizes(btnSize, imgSize);   
    int  i = 0;   
//	/*
    m_wndToolBar.SetButtonText(i++, "��������");   
    m_wndToolBar.SetButtonText(i++, "��ʷ����"); 
    m_wndToolBar.SetButtonText(i++, "��������"); 
    
//	m_wndToolBar.SetButtonText(i++, "��������");
	m_wndToolBar.SetButtonText(i++, "��    ��");

	m_wndToolBar.SetButtonText(i++, "�˳�ϵͳ");
	
  //  m_wndToolBar.SetButtonText(i++, "���ݲ�ѯ"); 
  //  m_wndToolBar.SetButtonText(i++, "����"); 
//*/
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
    m_wndToolBar.ShowWindow(SW_SHOW);
    RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);


//==new add ===
  	m_comm1.CommConnect(2);
	m_comm1.SetRevBufLen(9);
	m_comm1.SetRevBuf(&m_RevBuf1);
	m_comm1.SetupConnect(9600, 8, NOPARITY, ONESTOPBIT);

	ComRecvDataLen1 = 0;


m_schktime=FALSE;
GetDlgItem(IDC_EDIT_KTINT11)->SetWindowText("1000");

F_IniTreeall();

//xiniwqq();

wsdrec11="";
walarmrec11="";
wxfxrec11="";
jrecount11=0;

pwdsx11=pwdsx21=pwdsx31=pwdsx41=pwdsx51=pwdsx61=50000;
psdsx11=psdsx21=psdsx31=psdsx41=psdsx51=psdsx61=50000;

pwdxx11=pwdxx21=pwdxx31=pwdxx41=pwdxx51=pwdxx61=-50;
psdxx11=psdxx21=psdxx31=psdxx41=psdxx51=psdxx61=-50;


readtwsd(1);
readtwsd(2);
readtwsd(3);
readtwsd(4);
readtwsd(5);
readtwsd(6);

StxTime();

KtkOpenFile();

zkpiniRR11();

ZxydelFile();

SetTimer(2,1000,NULL);


return TRUE;  // return TRUE  unless you set the focus to a control

}

void CSuperdhDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSuperdhDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
	/*
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������
			LOGFONT m_logfnt; 
	m_logfnt.lfCharSet=DEFAULT_CHARSET;
	m_logfnt.lfClipPrecision=CLIP_DEFAULT_PRECIS;
	m_logfnt.lfEscapement=0;
	strcpy(m_logfnt.lfFaceName,"Times New Roman");
	m_logfnt.lfHeight=50;
	m_logfnt.lfItalic=false;
	m_logfnt.lfOrientation=0;
	m_logfnt.lfPitchAndFamily=FF_SWISS;
	m_logfnt.lfQuality=DEFAULT_QUALITY;
	m_logfnt.lfStrikeOut=false;
	m_logfnt.lfUnderline=true;
	m_logfnt.lfWeight=500;
	m_logfnt.lfWidth=15;
	m_logfnt.lfOutPrecision=OUT_DEFAULT_PRECIS;

	CFont m_font; 
	m_font.CreateFontIndirect(&m_logfnt); 
	CFont *pOldFont = dc.SelectObject(&m_font); 
	CString lpszString1="JUNZHE �� �� �� �� �� �� ϵ ͳ";

	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor(RGB(122,10,133));

	dc.TextOut(340,70,lpszString1,lstrlen(lpszString1)); 
	dc.SelectObject(pOldFont); 
	CDialog::OnPaint();
*/
	CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSuperdhDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSuperdhDlg::OnKKCommRxchar(WPARAM wParam, LPARAM lParam)
{
	SetDlgItemText(IDC_STATIC_WD11," �¶�:  ʪ��:456 ");

}

void CSuperdhDlg::OnCommRxchar(WPARAM wParam, LPARAM lParam)
{
	UINT port = (UINT)lParam;
//   AfxMessageBox("aaa13");

//	if (port == 1)
//	{
		BYTE *data;
		unsigned char ch1, ch2;
		int j,m ,k = 0;
		int wyadd=-1;

		int kwd11,kwd12,kwd21,kwd22,kwd31,kwd32,kwd41,kwd42,kwd51,kwd52,kwd61,kwd62;
     	
		int ksd11,ksd12,ksd21,ksd22,ksd31,ksd32,ksd41,ksd42,ksd51,ksd52,ksd61,ksd62;
   
	CTime wdktime;
	CString mp11,mp12,mp13,mp14,mp10,sp10,msp10;
		
		CString Swd11,Ssd11,RecCurr11;
  
        unsigned char m_cwuSBuf[10];
		
		int qwd11,qsd11,qfs;

	//	CString SendData,str,dispText;
int kfs11,kfs12,kfx11,kfx12;

		char SendData[256],dispText[512];
		int curChannel,len,sendlen;
		sendlen = 0;
		len = wParam;
//  CClientDC kdc(this);
	CString aa11,swfs11,swfx11,swft11;


		CString xbj11,xbj12,xbj13;
 //AfxMessageBox("aaa13");
	/*
	if (ComRecvDataLen1 >50)
		{
			ComRecvDataLen1 = 0;
			return; 
		}
		*/

	ComRecvDataLen1 = 0;
		data = m_comm1.GetData();
		for( m = 0; m < len; m++) {
			m_cComrcv1[ComRecvDataLen1++] = data[m];
	//		::Sleep(20);
		}
     //   m_comm1.
	//	CTime time = CTime::GetCurrentTime();

//		TRACE("The m_cAllrcv length:%d...\n",ComRecvDataLen1);
//		for(j = 0; j < 200; j++) m_cRcvData1[j] = 0;

		/*
		for(j = 0; j < ComRecvDataLen1; j++) {
			ch1 = (unsigned char)m_cComrcv1[j] / 16;
			ch2 = (unsigned char)m_cComrcv1[j] % 16;
			if(ch1 == 0) m_cRcvData1[k++] = '0';
			if((ch1 > 0) && (ch1 <= 9)) m_cRcvData1[k++] = ch1 + '0';
			if(ch1 >= 10) m_cRcvData1[k++] = ch1 - 10 + 'A';
			if(ch2 == 0) m_cRcvData1[k++] = '0';
			if((ch2 > 0) && (ch2 <= 9)) m_cRcvData1[k++] = ch2 + '0';
			if(ch2 >= 10) m_cRcvData1[k++] = ch2 - 10 + 'A';
			m_cRcvData1[k++] = ' ';
		}

*/

		m_cRcvData1[k] = '\0'; 
//		memset(dispText,0,sizeof(dispText));

//		sprintf(dispText,"%s  Receive:%s\r\n",time.Format(_T("%Y-%m-%d %H:%M:%S")),m_cRcvData1);
//         g_jzctrl=1;
	//	sprintf(dispText,"Receive:len=%d contens=  %s\r\n",len,m_cRcvData1);

//		sprintf(dispText,"Receive:  %s\r\n",m_cRcvData1);

//		if (g_bDispelco==TRUE)
//	 {
// kdc.TextOut(100,100,dispText,strlen(dispText));

	//		AfxMessageBox(dispText);
//	 }
// `  ======   deal  ========================
///*
	for(j = 0; j < ComRecvDataLen1-1; j++) {


  //    ========== left  ==============

	if ((m_cComrcv1[j]==0x01) && (m_cComrcv1[j+1]==0x03) && (fsfxseq==1))
		{

		 // AfxMessageBox("aaa");
     m_cwuSBuf[0]=m_cComrcv1[j];
     m_cwuSBuf[1]=m_cComrcv1[j+1];
     m_cwuSBuf[2]=m_cComrcv1[j+2];
     m_cwuSBuf[3]=m_cComrcv1[j+3];
     m_cwuSBuf[4]=m_cComrcv1[j+4];
   //  m_cwuSBuf[5]=m_cComrcv1[j+5];

    CRC16(m_cwuSBuf,5);
	//=========deal crc  
    m_cwuSBuf[5] =CRCHi;
    m_cwuSBuf[6] =CRCLo;

if ((m_cwuSBuf[5]==m_cComrcv1[j+5]) && (m_cwuSBuf[6]==m_cComrcv1[j+6]) )
{
  //   ====   1 ==========================

   kfs11=(m_cComrcv1[j+3] * 256 + m_cComrcv1[j+4])/10;

   kfs12=(m_cComrcv1[j+3] * 256 + m_cComrcv1[j+4])%10;

   qfs=m_cComrcv1[j+3] * 256 + m_cComrcv1[j+4];


   swfs11.Format("%d.%d",kfs11,kfs12);

   if (qfs<=2) swft11="0 ����";
   if ((qfs>2) && (qfs<=15)) swft11="1 ����";
   if ((qfs>16) && (qfs<=33)) swft11="2 ����";
   if ((qfs>34) && (qfs<=54)) swft11="3 ����";
  if ((qfs>54) && (qfs<=79)) swft11="4 ����";
 if ((qfs>79) && (qfs<=107)) swft11="5 ����";
 if ((qfs>107) && (qfs<=138)) swft11="6 ����";

 if ((qfs>139) && (qfs<=171)) swft11="7 ����";
 if ((qfs>172) && (qfs<=207)) swft11="8 ����";

 if ((qfs>207) && (qfs<=244)) swft11="9 ����";
 if ((qfs>244) && (qfs<=284)) swft11="10 ����";

if ((qfs>284) && (qfs<=326)) swft11="11 ����";

if ((qfs>327) && (qfs<=369)) swft11="12 ����";

if ((qfs>369) && (qfs<=414)) swft11="13 ����";


if ((qfs>414) && (qfs<=461)) swft11="14 ����";
if ((qfs>461) && (qfs<=509)) swft11="15 ����";

if ((qfs>509) && (qfs<=560)) swft11="16 ����";
if ((qfs>560) && (qfs<=612)) swft11="17 ����";

   SetDlgItemText(IDC_STA_FS11,"����: "+swfs11+" �� / �� "+swft11);
	
   SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+jkparea[0]);

if ( (jrecount11>kctlcout11) && (bkctlf11==0))
{
	

		wdktime = CTime::GetCurrentTime();

//	mp11.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

	mp11.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

	wxfxrec11=mp11+"����: "+swfs11+" �� / �� "+swft11+"\r\n"+wxfxrec11;
 
	sunrec12.WriteString(wxfxrec11);
    if (jrecount11>(kctlcout11+40)) jrecount11=0;

}

}   

	}

	if ((m_cComrcv1[j]==0x01) && (m_cComrcv1[j+1]==0x03) && (fsfxseq==2))
		{

		 // AfxMessageBox("aaa");
   m_cwuSBuf[0]=m_cComrcv1[j];
     m_cwuSBuf[1]=m_cComrcv1[j+1];
     m_cwuSBuf[2]=m_cComrcv1[j+2];
     m_cwuSBuf[3]=m_cComrcv1[j+3];
     m_cwuSBuf[4]=m_cComrcv1[j+4];
    //  m_cwuSBuf[5]=m_cComrcv1[j+5];

    CRC16(m_cwuSBuf,5);
	//=========deal crc  
    m_cwuSBuf[5] =CRCHi;
    m_cwuSBuf[6] =CRCLo;

if ((m_cwuSBuf[5]==m_cComrcv1[j+5]) && (m_cwuSBuf[6]==m_cComrcv1[j+6]) )
{

  //   ====   1 ==========================
   kfx11=m_cComrcv1[j+3] * 256 + m_cComrcv1[j+4];
   if (kfx11==225) swfx11="����ƫ��";
   if (kfx11==450) swfx11="��    ��";
   if (kfx11==675) swfx11="����ƫ��";
   if (kfx11==900) swfx11="  ��    ";

 if (kfx11==1125) swfx11="����ƫ��";
   if (kfx11==1350) swfx11="��    ��";
   if (kfx11==1575) swfx11="����ƫ��";
   if (kfx11==1800) swfx11="  ��    ";

    if (kfx11==2025) swfx11="����ƫ��";
   if (kfx11==2250) swfx11="��    ��";
   if (kfx11==2475) swfx11="����ƫ��";
   if (kfx11==2700) swfx11="  ��    ";

 if (kfx11==2925) swfx11="����ƫ��";
   if (kfx11==3150) swfx11="��    ��";
   if (kfx11==3375) swfx11="����ƫ��";
   if (kfx11==3600) swfx11="  ��    ";
  if (kfx11==0) swfx11="  ��    ";

   SetDlgItemText(IDC_STA_FX11,"����: "+swfx11);

 SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+jkparea[1]);
  
// if (jrecount11>kctlcout11)

if ( (jrecount11>kctlcout11) && (bkctlf11==0))
{
	
		wdktime = CTime::GetCurrentTime();

//	mp11.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

	mp11.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

	wxfxrec11=mp11+"����: "+swfx11+"\r\n"+wxfxrec11;

	sunrec12.WriteString(wxfxrec11);


SetDlgItemText(IDC_EDIT_FSFX,wxfxrec11);
 if (jrecount11>(kctlcout11+40)) jrecount11=0;

}

	}


}

	
	
	if ((m_cComrcv1[j]==0x03) && (m_cComrcv1[j+1]==0x04))
		{

		 // AfxMessageBox("aaa");

  //   ====   1 ==========================
      m_cwuSBuf[0]=m_cComrcv1[j-1];
      m_cwuSBuf[1]=m_cComrcv1[j];
     m_cwuSBuf[2]=m_cComrcv1[j+1];
     m_cwuSBuf[3]=m_cComrcv1[j+2];
     m_cwuSBuf[4]=m_cComrcv1[j+3];
     m_cwuSBuf[5]=m_cComrcv1[j+4];
     m_cwuSBuf[6]=m_cComrcv1[j+5];

    CRC16(m_cwuSBuf,7);
	//=========deal crc  
    m_cwuSBuf[7] =CRCHi;
    m_cwuSBuf[8] =CRCLo;

if ((m_cwuSBuf[7]==m_cComrcv1[j+6]) && (m_cwuSBuf[8]==m_cComrcv1[j+7]) )
{


      wyadd=(int)m_cComrcv1[j-1];
//	sprintf(dispText,"address:  %d",wyadd);
  //        AfxMessageBox(dispText);
 ///*
  kwd11 = (m_cComrcv1[j+2] * 256 + m_cComrcv1[j+3])/10;
        kwd12 = (m_cComrcv1[j+2] * 256 + m_cComrcv1[j+3])%10;
    
	if ((int)m_cComrcv1[j+2]==255)
	{
		qwd11=-(256-m_cComrcv1[j+3]);
        kwd11 = (256-m_cComrcv1[j+3])/10;
        kwd12 = (256-m_cComrcv1[j+3])%10;

		Swd11.Format("-%d.%d",kwd11,kwd12);
	}
	else
	{
	qwd11=m_cComrcv1[j+2] * 256 + m_cComrcv1[j+3];

		Swd11.Format("%d.%d",kwd11,kwd12);
	}
   ksd11 = (m_cComrcv1[j+4] * 256 + m_cComrcv1[j+5])/10;
        ksd12 = (m_cComrcv1[j+4] * 256 + m_cComrcv1[j+5])%10;
   
		qsd11=m_cComrcv1[j+4] * 256 + m_cComrcv1[j+5];

		Ssd11.Format("%d.%d ",ksd11,ksd12);

         RecCurr11.Format(" %d = %d ",sendseq,jrecount11);



	//	SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);


            switch (wyadd)
			{
         case 11:
 

			 
	SetDlgItemText(IDC_STATIC_WD11," �¶�: "+Swd11+" �� ");
	SetDlgItemText(IDC_STATIC_WD21," ʪ��: "+Ssd11+" % ");

 SetDlgItemText(IDC_STA_ECURR,"��ǰ���:"+jkparea[2]);
//sendseq=1;
//qwd11
  if ( (qwd11>=pwdsx11) || (qwd11<=pwdxx11) || (qsd11>=psdsx11) || (qsd11<=psdxx11))
{
		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());


	walarmrec11="��ǰ����:\r\n"+mp12+"--�����豸��1-- �¶�: "+Swd11+" ʪ��: "+Ssd11+walarmrec11+"\r\n";

 SetDlgItemText(IDC_EDIT_WSDALARM,walarmrec11);
	 if (bkctlf11==0)
  {

	sunalarm11.WriteString(walarmrec11);
	 }

		Beep(800,500);
	GetDlgItem(IDC_STA_ALARM11)->ShowWindow(SW_SHOW);
  }
  else
  {
	  	GetDlgItem(IDC_STA_ALARM11)->ShowWindow(SW_HIDE);
  }
 
 //if (jrecount11>kctlcout12)

 if ( (jrecount11>kctlcout12) && (bkctlf11==0))
 {
	

		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());


	wsdrec11=mp12+"--�����豸��1-- �¶�: "+Swd11+" �� "+" ʪ��: "+Ssd11+" %  \r\n"+wsdrec11;


	sunrec11.WriteString(wsdrec11);
 if (jrecount11>(kctlcout11+40)) jrecount11=0;

}

        break;
       case 12:
     
	SetDlgItemText(IDC_STATIC_WDD12," �¶�: "+Swd11+" �� ");
	SetDlgItemText(IDC_STATIC_WDD22," ʪ��: "+Ssd11+" % ");
//sendseq=2;
//SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);

 SetDlgItemText(IDC_STA_ECURR,"��ǰ���:"+jkparea[3]);

  if ( (qwd11>=pwdsx21) || (qwd11<=pwdxx21) || (qsd11>=psdsx21) || (qsd11<=psdxx21))
{
		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

//	walarmrec11=mp12+"--��ʪ��2-- �¶�: "+Swd11+" �� "+" ʪ��: "+Ssd11+" % "+walarmrec11+"\r\n";

// SetDlgItemText(IDC_EDIT_WSDALARM,"��ǰ����:"+walarmrec11);

	walarmrec11="��ǰ����:\r\n"+mp12+"--�����豸��2-- �¶�: "+Swd11+" ʪ��: "+Ssd11+walarmrec11+"\r\n";

 SetDlgItemText(IDC_EDIT_WSDALARM,walarmrec11);


	 if (bkctlf11==0)
  {
	sunalarm11.WriteString(walarmrec11);
	 }

	Beep(800,500);
	GetDlgItem(IDC_STA_ALARM12)->ShowWindow(SW_SHOW);
  }
  else
  {
	  	GetDlgItem(IDC_STA_ALARM12)->ShowWindow(SW_HIDE);
  }


//if (jrecount11>kctlcout12)

if ( (jrecount11>kctlcout12) && (bkctlf11==0))
{
	

		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());
//	wsdrec11=wsdrec11+mp12+"--��ʪ��1-- �¶�: "+Swd11+" ʪ��: "+Ssd11;
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

	wsdrec11=mp12+ "--�����豸��2-- �¶�: "+Swd11+" �� "+" ʪ��: "+Ssd11+" %  \r\n"+wsdrec11;
	sunrec11.WriteString(wsdrec11);
 if (jrecount11>(kctlcout11+40)) jrecount11=0;
}


        break;
       case 13:
	
//		   SetDlgItemText(IDC_STATIC_WD13," �¶�: "+Swd11+" ʪ��: "+Ssd11);
	
		   SetDlgItemText(IDC_STATIC_WDD13," �¶�: "+Swd11+" �� ");
	SetDlgItemText(IDC_STATIC_WDD23," ʪ��: "+Ssd11+" % ");

//sendseq=3;
//	SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);

 SetDlgItemText(IDC_STA_ECURR,"��ǰ���:"+jkparea[4]);

   if ( (qwd11>=pwdsx31) || (qwd11<=pwdxx31) || (qsd11>=psdsx31) || (qsd11<=psdxx31))
{
		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

//	walarmrec11=mp12+"--��ʪ��3-- �¶�: "+Swd11+" ʪ��: "+" �� "+Ssd11+" % "+walarmrec11+"\r\n";

// SetDlgItemText(IDC_EDIT_WSDALARM,"��ǰ����:"+walarmrec11);

 	walarmrec11="��ǰ����: \r\n"+mp12+"--�����豸��3-- �¶�: "+Swd11+" ʪ��: "+Ssd11+walarmrec11+"\r\n";

 SetDlgItemText(IDC_EDIT_WSDALARM,walarmrec11);
 
 if (bkctlf11==0)
  {

	sunalarm11.WriteString(walarmrec11);
	 }

		Beep(800,500);
	GetDlgItem(IDC_STA_ALARM13)->ShowWindow(SW_SHOW);
  }
  else
  {
	  	GetDlgItem(IDC_STA_ALARM13)->ShowWindow(SW_HIDE);
  }



//if (jrecount11>kctlcout12)

if ( (jrecount11>kctlcout12) && (bkctlf11==0))
{
	

		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());
//	wsdrec11=wsdrec11+mp12+"--��ʪ��1-- �¶�: "+Swd11+" ʪ��: "+Ssd11;
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

//	wsdrec11=mp12+"--�����豸��3-- �¶�: "+Swd11+" ʪ��: "+Ssd11+wsdrec11;

	wsdrec11=mp12+ "--�����豸��3-- �¶�: "+Swd11+" �� "+" ʪ��: "+Ssd11+" %  \r\n"+wsdrec11;

SetDlgItemText(IDC_EDIT_WSDTREC,wsdrec11);
//jrecount11=0;
	sunrec11.WriteString(wsdrec11);
 if (jrecount11>(kctlcout11+40)) jrecount11=0;
}


        break;
       case 14:
 	
		SetDlgItemText(IDC_STATIC_WDD14," �¶�: "+Swd11+" �� ");
	SetDlgItemText(IDC_STATIC_WDD24," ʪ��: "+Ssd11+" % ");

//	SetDlgItemText(IDC_STATIC_WD14," �¶�: "+Swd11+" ʪ��: "+Ssd11);

	
//	SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);

 SetDlgItemText(IDC_STA_ECURR,"��ǰ���:"+jkparea[5]);

   if ( (qwd11>=pwdsx41) || (qwd11<=pwdxx41) || (qsd11>=psdsx41) || (qsd11<=psdxx41))
{
		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());


//	walarmrec11=mp12+"--��ʪ��4-- �¶�: "+Swd11+" ʪ��: "+Ssd11+walarmrec11+"\r\n";
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

// SetDlgItemText(IDC_EDIT_WSDALARM,"��ǰ����:"+walarmrec11);

 	walarmrec11="��ǰ����: \r\n"+mp12+"--35KV������1-- �¶�: "+Swd11+" ʪ��: "+Ssd11+walarmrec11+"\r\n";

 SetDlgItemText(IDC_EDIT_WSDALARM,walarmrec11);

 if (bkctlf11==0)
  {
	sunalarm11.WriteString(walarmrec11);
	 }

		Beep(800,500);
	GetDlgItem(IDC_STA_ALARM14)->ShowWindow(SW_SHOW);
  }
  else
  {
	  	GetDlgItem(IDC_STA_ALARM14)->ShowWindow(SW_HIDE);
  }


//if (jrecount11>kctlcout12)

if ( (jrecount11>kctlcout12) && (bkctlf11==0))
{
	

		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());
//	wsdrec11=wsdrec11+mp12+"--��ʪ��1-- �¶�: "+Swd11+" ʪ��: "+Ssd11;
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

//	wsdrec11=mp12+"--35KV������1-- �¶�: "+Swd11+" ʪ��: \r\n"+Ssd11+wsdrec11;
	wsdrec11=mp12+ "--35KV������1-- �¶�: "+Swd11+" �� "+" ʪ��: "+Ssd11+" %  \r\n"+wsdrec11;

	sunrec11.WriteString(wsdrec11);

 if (jrecount11>(kctlcout11+40)) jrecount11=0;

}
        break;
   
     case 15:

  // 	SetDlgItemText(IDC_STATIC_WD15," �¶�: "+Swd11+" ʪ��: "+Ssd11);

	SetDlgItemText(IDC_STATIC_WDD15," �¶�: "+Swd11+" �� ");
	SetDlgItemText(IDC_STATIC_WDD25," ʪ��: "+Ssd11+" % ");

//	SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);

	 SetDlgItemText(IDC_STA_ECURR,"��ǰ���:"+jkparea[6]);

  if ( (qwd11>=pwdsx51) || (qwd11<=pwdxx51) || (qsd11>=psdsx51) || (qsd11<=psdxx51))
{
		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());


//	walarmrec11=walarmrec11+mp12+"--��ʪ��5-- �¶�: "+Swd11+" ʪ��: "+Ssd11+"\r\n";
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

// SetDlgItemText(IDC_EDIT_WSDALARM,"��ǰ����:"+walarmrec11);

 	walarmrec11="��ǰ����: \r\n"+mp12+"--35KV������2-- �¶�: "+Swd11+" ʪ��: "+Ssd11+walarmrec11+"\r\n";

 SetDlgItemText(IDC_EDIT_WSDALARM,walarmrec11);

	 if (bkctlf11==0)
  {
	sunalarm11.WriteString(walarmrec11);
	 }

		Beep(800,500);
	GetDlgItem(IDC_STA_ALARM15)->ShowWindow(SW_SHOW);
  }
  else
  {
	  	GetDlgItem(IDC_STA_ALARM15)->ShowWindow(SW_HIDE);
  }



//if (jrecount11>kctlcout12)

if ( (jrecount11>kctlcout12) && (bkctlf11==0))
{
	

		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());
//	wsdrec11=wsdrec11+mp12+"--��ʪ��1-- �¶�: "+Swd11+" ʪ��: "+Ssd11;
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

//	wsdrec11=mp12+"--35KV������2-- �¶�: "+Swd11+" ʪ��: \r\n"+Ssd11+wsdrec11;

	wsdrec11=mp12+ "--35KV������2-- �¶�: "+Swd11+" �� "+" ʪ��: "+Ssd11+" %  \r\n"+wsdrec11;

	sunrec11.WriteString(wsdrec11);
 if (jrecount11>(kctlcout11+40)) jrecount11=0;

}

        break;
    case 16:

 //	SetDlgItemText(IDC_STATIC_WD16," �¶�: "+Swd11+" ʪ��: "+Ssd11);

	SetDlgItemText(IDC_STATIC_WD16," �¶�: "+Swd11+" �� ");
	SetDlgItemText(IDC_STATIC_WD26," ʪ��: "+Ssd11+" % ");

//	SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);

 SetDlgItemText(IDC_STA_ECURR,"��ǰ���:"+jkparea[7]);

  if ( (qwd11>=pwdsx61) || (qwd11<=pwdxx61) || (qsd11>=psdsx61) || (qsd11<=psdxx61))
{
		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());


//	walarmrec11=walarmrec11+mp12+"--��ʪ��5-- �¶�: "+Swd11+" ʪ��: "+Ssd11+"\r\n";
	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

// SetDlgItemText(IDC_EDIT_WSDALARM,"��ǰ����:"+walarmrec11);

 	walarmrec11="��ǰ����: \r\n"+mp12+"--35KV������3-- �¶�: "+Swd11+" ʪ��: "+Ssd11+walarmrec11+"\r\n";

 SetDlgItemText(IDC_EDIT_WSDALARM,walarmrec11);


	 if (bkctlf11==0)
  {
	sunalarm11.WriteString(walarmrec11);
	 }

		Beep(800,500);
	GetDlgItem(IDC_STA_ALARM16)->ShowWindow(SW_SHOW);
  }
  else
  {
	  	GetDlgItem(IDC_STA_ALARM16)->ShowWindow(SW_HIDE);
  }


//if (jrecount11>kctlcout12)

if ( (jrecount11>kctlcout12) && (bkctlf11==0))

{
	

		wdktime = CTime::GetCurrentTime();

//	mp12.Format("%2d:%2d:%2d",wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());
//	wsdrec11=wsdrec11+mp12+"--��ʪ��1-- �¶�: "+Swd11+" ʪ��: "+Ssd11;

//	wsdrec11=mp12+"--35KV������3-- �¶�: "+Swd11+" ʪ��: \r\n"+Ssd11+wsdrec11;
 	mp12.Format("%04d��% 02d�� %02d��  %02d :%02d :%02d",wdktime.GetYear(), wdktime.GetMonth(), wdktime.GetDay(),wdktime.GetHour(),wdktime.GetMinute(),wdktime.GetSecond());

		wsdrec11=mp12+ "--35KV������3-- �¶�: "+Swd11+" �� "+" ʪ��: "+Ssd11+" %  \r\n"+wsdrec11;

	
	wsdrec11=wsdrec11+"\r\n";
  //  jrecount11=0;

SetDlgItemText(IDC_EDIT_WSDTREC,wsdrec11);
	sunrec11.WriteString(wsdrec11);
   jrecount11=0;

}

        break;
   
		 default:
//	m_nCurChannel = -1;
  break;
			}

			}
 //*/
//			Sleep(50);

		}



			}
//*/
  //      ===========  5     ==============

}

void CSuperdhDlg::sendwd11()
{
	unsigned char m_cSBuf[8];

//m_cSBuf[0]=address;

	m_cSBuf[0] =0x02;
  
	m_cSBuf[1] =0x03;

//    m_cSBuf[2] =address;

   m_cSBuf[2] = 0x00;
   
   m_cSBuf[3] =0x2A;

    m_cSBuf[4] =0x00;

    m_cSBuf[5] =0x01;

CRC16(m_cSBuf,6);
	//=========deal crc  
    m_cSBuf[6] =CRCHi;
    m_cSBuf[7] =CRCLo;

	m_comm1.WriteCom(m_cSBuf,8);

}

void CSuperdhDlg::OnButDhsend() 
{
	// TODO: Add your control notification handler code here
//		Beep(800,500);
//	GetDlgItem(IDC_STA_ALARM11)->ShowWindow(SW_SHOW);


	//	Beep(1000,500);

	/*
if (sendseq==0) 
{
	sendseq=1;
ggsendwsd(1);
return;
}
if (sendseq==2) 
{
	sendseq=3;
ggsendwsd(3);
return;
}
//*/
//Sleep(100);

//ggsendwsd(1);
//Sleep(100);


//ggsendwsd(13);

//KtkOpenFile();

}

void CSuperdhDlg::ggsendwsd(int gadd)
{
	unsigned char m_cSBuf[8];

//m_cSBuf[0]=address;

	m_cSBuf[0] =gadd;
  
	m_cSBuf[1] =0x03;

//    m_cSBuf[2] =address;

   m_cSBuf[2] = 0x00;
   
   m_cSBuf[3] =0x00;

    m_cSBuf[4] =0x00;

    m_cSBuf[5] =0x02;

CRC16(m_cSBuf,6);
	//=========deal crc  
    m_cSBuf[6] =CRCHi;
    m_cSBuf[7] =CRCLo;

	m_comm1.WriteCom(m_cSBuf,8);

}

void CSuperdhDlg::OnButDhkw11() 
{
	// TODO: Add your control notification handler code here
//ZxydelFile();

}

void CSuperdhDlg::OnButDhkw12() 
{
	// TODO: Add your control notification handler code here
	CString hgtime,hgtime01;
	int ggtime;
	GetDlgItem(IDC_EDIT_KTINT11)->GetWindowText(hgtime);

ggtime=atoi(hgtime);
//	SetTimer(1,ggtime,NULL);

	SetTimer(1,1000,NULL);
   m_schktime = TRUE;

GetDlgItem(IDC_BUT_DHKW12)->EnableWindow(FALSE);

}

void CSuperdhDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnTimer(nIDEvent);


		CString csTemp11 = _T("");
	m_curTime	=	COleDateTime::GetCurrentTime();
///*
	if (nIDEvent == 2)
	{
		
//	csTemp11.Format("\n%04d��%02d��%02d��\n%s\n%02d:%02d:%02d", m_curTime.GetYear(), m_curTime.GetMonth(), m_curTime.GetDay(),DayOfWeek[m_curTime.GetDayOfWeek()-1], m_curTime.GetHour(),m_curTime.GetMinute(),m_curTime.GetSecond());
//		csTemp11.Format("\n%04d��%02d��%02d��\n%s\n%02d:%02d:%02d", m_curTime.GetYear(), m_curTime.GetMonth(), m_curTime.GetDay(), m_curTime.GetHour(),m_curTime.GetMinute(),m_curTime.GetSecond());

		csTemp11.Format("\n%04d��% 02d�� %02d��  %02d :%02d :%02d", m_curTime.GetYear(), m_curTime.GetMonth(), m_curTime.GetDay(), m_curTime.GetHour(),m_curTime.GetMinute(),m_curTime.GetSecond());


		GetDlgItem(IDC_STATIC_TIME)->SetWindowText(csTemp11);

     KdtOpenFile();
 
	}
//*/

if (nIDEvent == 1)
	{
	jrecount11++;
TScan11();
Sleep(200);
TScan12();

}



}

void CSuperdhDlg::TScan11()
{
	CString RecCurr11;
	

if (sendseq==0) 
{
	sendseq=1;

ggsendwsd(11);
//	RecCurr11.Format(" %d ",sendseq);


//		SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);
return;
}
if (sendseq==1) 
{
//	Sleep(100);
sendseq=2;
	ggsendwsd(12);
//		RecCurr11.Format(" %d ",sendseq);


//		SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);
	return;
}

if (sendseq==2) 
{
//	Sleep(100);
sendseq=3;
	ggsendwsd(13);
//		RecCurr11.Format(" %d ",sendseq);


//		SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);
	return;
}

if (sendseq==3) 
{
	sendseq=4;
ggsendwsd(14);
//	RecCurr11.Format(" %d ",sendseq);


//		SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);
return;
}

if (sendseq==4) 
{
//	Sleep(100);
sendseq=5;
	ggsendwsd(15);
//		RecCurr11.Format(" %d ",sendseq);


//		SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);
	return;
}

if (sendseq==5) 
{
//	Sleep(100);
//sendseq=6;
	ggsendwsd(16);
//		RecCurr11.Format(" %d ",sendseq);


//		SetDlgItemText(IDC_STA_DCURR,"��ǰ���:"+RecCurr11);
	sendseq=0;
		return;
}




}

void CSuperdhDlg::OnButStop() 
{
	// TODO: Add your control notification handler code here
		KillTimer(1);
		m_schktime=FALSE;
		GetDlgItem(IDC_BUT_DHKW12)->EnableWindow(TRUE);

	SetDlgItemText(IDC_STATIC_WD11," �¶�: ");
	SetDlgItemText(IDC_STATIC_WD21," ʪ��: ");

SetDlgItemText(IDC_STATIC_WDD12," �¶�: ");
	SetDlgItemText(IDC_STATIC_WDD22," ʪ��: ");

	SetDlgItemText(IDC_STATIC_WDD13," �¶�: ");
	SetDlgItemText(IDC_STATIC_WDD23," ʪ��: ");
	SetDlgItemText(IDC_STATIC_WDD14," �¶�: ");
	SetDlgItemText(IDC_STATIC_WDD24," ʪ��: ");

	SetDlgItemText(IDC_STATIC_WDD15," �¶�: ");
	SetDlgItemText(IDC_STATIC_WDD25," ʪ��: ");
	SetDlgItemText(IDC_STATIC_WD16," �¶�: ");
	SetDlgItemText(IDC_STATIC_WD26," ʪ��: ");

}

void CSuperdhDlg::OnButWyexit() 
{
	// TODO: Add your control notification handler code here
			  if (IDOK != MessageBox("ȷ��Ҫ�˳�?","Warning",IDOK))
    {
      
			  return;
    }

	if (m_schktime == TRUE)
	{

	KillTimer(1);
	}
CDialog::EndDialog(1);

}

void CSuperdhDlg::xiniwqq()
{
	DWORD dwf = CGfxOutBarCtrl::fDragItems|CGfxOutBarCtrl::fEditGroups|CGfxOutBarCtrl::fEditItems|CGfxOutBarCtrl::fRemoveGroups|
		CGfxOutBarCtrl::fRemoveItems|CGfxOutBarCtrl::fAddGroups|CGfxOutBarCtrl::fAnimation
		|CGfxOutBarCtrl::fSelHighlight;
	CRect rc,rc11;
	GetClientRect(&rc);
  //  rc11=CRect(120,0,200,300);

    rc11=CRect(0,220,200,600);

	wndBar.Create(WS_CHILD|WS_VISIBLE, rc11, this,IDC_LST_MENU, dwf);
	wndBar.SetOwner(this);
		//���������ô�Сͼ������
	imaLarge.Create(32,32,ILC_COLOR32|ILC_MASK,0,0);
	imaSmall.Create(16,16,ILC_COLOR32|ILC_MASK,0,0);
	imaLarge.Add(::AfxGetApp()->LoadIcon(IDI_ICON1));
	imaLarge.Add(::AfxGetApp()->LoadIcon(IDI_ICON2));
	imaLarge.Add(::AfxGetApp()->LoadIcon(IDI_ICON3));
	imaLarge.Add(::AfxGetApp()->LoadIcon(IDI_ICON4));
	imaLarge.Add(::AfxGetApp()->LoadIcon(IDI_ICON5));
	imaLarge.Add(::AfxGetApp()->LoadIcon(IDI_ICON6));
	imaLarge.Add(::AfxGetApp()->LoadIcon(IDI_ICON7));
	imaSmall.Add(::AfxGetApp()->LoadIcon(IDI_ICON1));
	imaSmall.Add(::AfxGetApp()->LoadIcon(IDI_ICON2));
	imaSmall.Add(::AfxGetApp()->LoadIcon(IDI_ICON3));
	imaSmall.Add(::AfxGetApp()->LoadIcon(IDI_ICON4));
	imaSmall.Add(::AfxGetApp()->LoadIcon(IDI_ICON5));
	imaSmall.Add(::AfxGetApp()->LoadIcon(IDI_ICON6));
	imaSmall.Add(::AfxGetApp()->LoadIcon(IDI_ICON7));
	wndBar.SetImageList(&imaLarge, CGfxOutBarCtrl::fLargeIcon);
	wndBar.SetImageList(&imaSmall, CGfxOutBarCtrl::fSmallIcon);
	//����4������
	wndBar.SetAnimationTickCount(20);
	wndBar.SetAnimSelHighlight(200);
	wndBar.AddFolder("�������",0);
	wndBar.AddFolder("�¶�ʪ��",1);
//	wndBar.AddFolder("��������",2);

//	wndBar.AddFolder("��ʷ����",3);
//	wndBar.AddFolder("��ѹͨ��2",4);


//	wndBar.AddFolder("�й�����ͨ��1",5);
//    wndBar.AddFolder("�й�����ͨ��2",6);


	//����һ�������ͼ�갴ť
	wndBar.InsertItem(0, 0, "��  ��", 0, 0);
	wndBar.InsertItem(0, 1, "��  ��", 2, 0);

	//���ڶ��������ͼ�갴ť
	wndBar.InsertItem(1, 0, "��ʪ��1", 0, 0);
	wndBar.InsertItem(1, 1, "��ʪ��2", 2, 0);
	wndBar.InsertItem(1, 2, "��ʪ��3", 3, 0);
	wndBar.InsertItem(1, 3, "��ʪ��4", 4, 0);
	wndBar.InsertItem(1, 4, "��ʪ��5", 3, 0);
	wndBar.InsertItem(1, 5, "��ʪ��6", 3, 0);
	//���ڶ��������ͼ�갴ť
//	wndBar.InsertItem(2, 0, "��ʪ��1����", 0, 0);
//	wndBar.InsertItem(2, 1, "��ʪ��2����", 2, 0);
//	wndBar.InsertItem(2, 2, "��ʪ��3����", 3, 0);
//	wndBar.InsertItem(2, 3, "��ʪ��4����", 4, 0);
//	wndBar.InsertItem(2, 4, "��ʪ��5����", 3, 0);
//	wndBar.InsertItem(2, 5, "��ʪ��6����", 3, 0);
		//���ڶ��������ͼ�갴ť
//	wndBar.InsertItem(3, 0, "��ʪ��1", 0, 0);
//	wndBar.InsertItem(3, 1, "��ʪ��2", 2, 0);
//	wndBar.InsertItem(3, 2, "��ʪ��3", 3, 0);
//	wndBar.InsertItem(3, 3, "��ʪ��4", 4, 0);
//	wndBar.InsertItem(3, 4, "��ʪ��5", 3, 0);
//	wndBar.InsertItem(3, 5, "��ʪ��6", 3, 0);
	//�򿪵�һ������
	wndBar.SetSelFolder(1);
	// TODO: Add extra initialization here


}


long CSuperdhDlg::OnOutbarNotify(WPARAM wParam, LPARAM lParam)
{
//	return 1;
	switch (wParam)
	{
		case NM_OB_ITEMCLICK:
		// cast the lParam to an integer to get the clicked item
			{
				int inde11 = (int) wParam;
	            int inde12 = (int) lParam;

				CString cs, cs1;
				cs1 = wndBar.GetItemText(inde12);
				cs.Format("Clicked on %d - <%d>", (int)inde11, (int)inde12);
		//		AfxMessageBox(cs);
	    // AfxMessageBox(cs1);
  if (cs1=="��  ��")
			  {
       sendfs11();

			  }
 if (cs1=="��  ��")
			  {
       sendfx11();

			  }

    if (cs1=="��ʪ��1")
			  {
       ggsendwsd(11);

			  }

      if (cs1=="��ʪ��2")
			  {
       ggsendwsd(12);

			  }

	    if (cs1=="��ʪ��3")
			  {
       ggsendwsd(13);

			  }

      if (cs1=="��ʪ��4")
			  {
       ggsendwsd(14);

			  }

	     if (cs1=="��ʪ��5")
			  {
       ggsendwsd(15);

			  }
    if (cs1=="��ʪ��6")
			  {
       ggsendwsd(16);

			  }

			}
		return 0;

		case NM_OB_ONLABELENDEDIT:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the edited item
		// return 1 to do the change and 0 to cancel it
			{
				OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
				TRACE2("Editing item %d, new text:%s\n", pOI->index, pOI->cText);
			}
		return 1;

		case NM_OB_ONGROUPENDEDIT:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the edited folder
		// return 1 to do the change and 0 to cancel it
			{
				OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
				TRACE2("Editing folder %d, new text:%s\n", pOI->index, pOI->cText);
			}
		return 1;

		case NM_OB_DRAGITEM:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the dragged items
		// return 1 to do the change and 0 to cancel it
			{
				OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
				TRACE2("Drag item %d at position %d\n", pOI->iDragFrom, pOI->iDragTo);
			}
		return 1;
	}
	return 0;

}

void CSuperdhDlg::sendfx11()
{
	unsigned char m_cSBuf[8];

//m_cSBuf[0]=address;

	m_cSBuf[0] =0x01;
  
	m_cSBuf[1] =0x03;

//    m_cSBuf[2] =address;

   m_cSBuf[2] = 0x00;
   
   m_cSBuf[3] =0x2B;

    m_cSBuf[4] =0x00;

    m_cSBuf[5] =0x01;

CRC16(m_cSBuf,6);
	//=========deal crc  
    m_cSBuf[6] =CRCHi;
    m_cSBuf[7] =CRCLo;

	m_comm1.WriteCom(m_cSBuf,8);
	fsfxseq=2;

}

void CSuperdhDlg::OnWsdbjset() 
{
	// TODO: Add your command handler code here
	CWSDSetDlg  xwsddlg;
        xwsddlg.jkpoint=0;

		xwsddlg.DoModal();

if (xwsddlg.ctlkdg11==1)
{
		switch(xwsddlg.jkpoint)
		{
		case 1:
              pwdsx11=xwsddlg.pwdsx11;
              pwdxx11=xwsddlg.pwdxx11;
			  psdsx11=xwsddlg.psdsx11;
              psdxx11=xwsddlg.psdxx11;
			  break;
	    case 2:
              pwdsx21=xwsddlg.pwdsx21;
              pwdxx21=xwsddlg.pwdxx21;
			  psdsx21=xwsddlg.psdsx21;
              psdxx21=xwsddlg.psdxx21;
			  break;
		case 3:
              pwdsx31=xwsddlg.pwdsx31;
              pwdxx31=xwsddlg.pwdxx31;
			  psdsx31=xwsddlg.psdsx31;
              psdxx31=xwsddlg.psdxx31;
			  break;
	    case 4:
              pwdsx41=xwsddlg.pwdsx41;
              pwdxx41=xwsddlg.pwdxx41;
			  psdsx41=xwsddlg.psdsx41;
              psdxx41=xwsddlg.psdxx41;
			  break;
	    case 5:
              pwdsx51=xwsddlg.pwdsx51;
              pwdxx51=xwsddlg.pwdxx51;
			  psdsx51=xwsddlg.psdsx51;
              psdxx51=xwsddlg.psdxx51;
			  break;
	    case 6:
              pwdsx61=xwsddlg.pwdsx61;
              pwdxx61=xwsddlg.pwdxx61;
			  psdsx61=xwsddlg.psdsx61;
              psdxx61=xwsddlg.psdxx61;
			  break;
		default:
			  break;

		}

}



}

void CSuperdhDlg::OnWzsexit() 
{
	// TODO: Add your command handler code here
				  if (IDOK != MessageBox("ȷ��Ҫ�˳�?","Warning",IDOK))
    {
      
			  return;
    }

	if (m_schktime == TRUE)
	{

	KillTimer(1);
	}

sunrec11.Close();
sunrec12.Close();

sunalarm11.Close();

CDialog::EndDialog(1);


}

void CSuperdhDlg::OnWzsabt() 
{
	// TODO: Add your command handler code here
	CAboutDlg kbglg;
	kbglg.DoModal();

}

void CSuperdhDlg::readtwsd(int pp11)
{
			char cWorkDir[256];
		 char ww[1];
		 	char buf[256];

	CStdioFile wsdbjFile;
	GetCurrentDirectory(256, cWorkDir);
	int jkpk11,mh11;

    CString avsunrec11,saoft11,scom_wsdp;
    CString wsdsxpa11,wsdsxpa12;

    CString wdsx11,wdsx12,wdxx11,wdxx12;
	CString sdsx11,sdsx12,sdxx11,sdxx12;

   // CTime saotime11 = CTime::GetCurrentTime();
//	saoft11= saotime11.Format(_T("%Y_%m_%d_%H_%M_%S"));

//jkpk11=1;


	  wsdsxpa11.Format("%s\\wsdpara\\wsdsx%d.dsun", cWorkDir, pp11);
	  
	//  AfxMessageBox(wsdsxpa11);

	if (wsdbjFile.Open(wsdsxpa11, CFile::modeRead) == FALSE)
	{
//	 AfxMessageBox("����ʪ�ȱ�����,����������ʪ��!");
		return;
	}

    int jj11=0;

	switch(pp11)
	{
	case 1:
	while (wsdbjFile.ReadString(buf,256))
	{
jj11++;
if (jj11==2)
{
	wdsx11=buf;


	wdsx11=wdsx11.Left(wdsx11.GetLength()-2);

	pwdsx11=atoi(wdsx11)*10;
}
if (jj11==3)
{
	wdsx12=buf;

	wdsx12=wdsx12.Left(wdsx12.GetLength()-2);

	pwdsx11=pwdsx11+atoi(wdsx12);

}
if (jj11==4)
{
	wdxx11=buf;
	
	wdxx11=wdxx11.Left(wdxx11.GetLength()-2);
	pwdxx11=atoi(wdxx11)*10;

}

if (jj11==5)
{
	wdxx12=buf;
	wdxx12=wdxx12.Left(wdxx12.GetLength()-2);

	pwdxx11=pwdxx11+atoi(wdxx12);


}

if (jj11==6)
{
	sdsx11=buf;
	
	sdsx11=sdsx11.Left(sdsx11.GetLength()-2);

	psdsx11=atoi(sdsx11)*10;

}
if (jj11==7)
{
	sdsx12=buf;

	sdsx12=sdsx12.Left(sdsx12.GetLength()-2);

	psdsx11=psdsx11+atoi(sdxx12);

}
if (jj11==8)
{
	sdxx11=buf;
	
	sdxx11=sdxx11.Left(sdxx11.GetLength()-2);

	psdxx11=atoi(sdxx11)*10;

}

if (jj11==9)
{
	sdxx12=buf;
		
	sdxx12=sdxx12.Left(sdxx12.GetLength()-2);

	psdxx11=psdxx11+atoi(sdxx12);
}


	}
	break;
	case 2:

	while (wsdbjFile.ReadString(buf,256))
	{
jj11++;
if (jj11==2)
{
	wdsx11=buf;


	wdsx11=wdsx11.Left(wdsx11.GetLength()-2);

	pwdsx21=atoi(wdsx11)*10;
}
if (jj11==3)
{
	wdsx12=buf;

	wdsx12=wdsx12.Left(wdsx12.GetLength()-2);

	pwdsx21=pwdsx21+atoi(wdsx12);

}
if (jj11==4)
{
	wdxx11=buf;
	
	wdxx11=wdxx11.Left(wdxx11.GetLength()-2);
	pwdxx21=atoi(wdxx11)*10;

}

if (jj11==5)
{
	wdxx12=buf;
	wdxx12=wdxx12.Left(wdxx12.GetLength()-2);

	pwdxx21=pwdxx21+atoi(wdxx12);


}

if (jj11==6)
{
	sdsx11=buf;
	
	sdsx11=sdsx11.Left(sdsx11.GetLength()-2);

	psdsx21=atoi(sdsx11)*10;

}
if (jj11==7)
{
	sdsx12=buf;

	sdsx12=sdsx12.Left(sdsx12.GetLength()-2);

	psdsx21=psdsx21+atoi(sdxx12);

}
if (jj11==8)
{
	sdxx11=buf;
	
	sdxx11=sdxx11.Left(sdxx11.GetLength()-2);

	psdxx21=atoi(sdxx11)*10;

}

if (jj11==9)
{
	sdxx12=buf;
		
	sdxx12=sdxx12.Left(sdxx12.GetLength()-2);

	psdxx21=psdxx21+atoi(sdxx12);
}

	}


		break;
	case 3:

			while (wsdbjFile.ReadString(buf,256))
	{
jj11++;
if (jj11==2)
{
	wdsx11=buf;


	wdsx11=wdsx11.Left(wdsx11.GetLength()-2);

	pwdsx31=atoi(wdsx11)*10;
}
if (jj11==3)
{
	wdsx12=buf;

	wdsx12=wdsx12.Left(wdsx12.GetLength()-2);

	pwdsx31=pwdsx31+atoi(wdsx12);

}
if (jj11==4)
{
	wdxx11=buf;
	
	wdxx11=wdxx11.Left(wdxx11.GetLength()-2);
	pwdxx31=atoi(wdxx11)*10;

}

if (jj11==5)
{
	wdxx12=buf;
	wdxx12=wdxx12.Left(wdxx12.GetLength()-2);

	pwdxx31=pwdxx31+atoi(wdxx12);


}

if (jj11==6)
{
	sdsx11=buf;
	
	sdsx11=sdsx11.Left(sdsx11.GetLength()-2);

	psdsx31=atoi(sdsx11)*10;

}
if (jj11==7)
{
	sdsx12=buf;

	sdsx12=sdsx12.Left(sdsx12.GetLength()-2);

	psdsx31=psdsx31+atoi(sdxx12);

}
if (jj11==8)
{
	sdxx11=buf;
	
	sdxx11=sdxx11.Left(sdxx11.GetLength()-2);

	psdxx31=atoi(sdxx11)*10;

}

if (jj11==9)
{
	sdxx12=buf;
		
	sdxx12=sdxx12.Left(sdxx12.GetLength()-2);

	psdxx31=psdxx31+atoi(sdxx12);
}

	}


		break;
	case 4:

					while (wsdbjFile.ReadString(buf,256))
	{
jj11++;
if (jj11==2)
{
	wdsx11=buf;


	wdsx11=wdsx11.Left(wdsx11.GetLength()-2);

	pwdsx41=atoi(wdsx11)*10;
}
if (jj11==3)
{
	wdsx12=buf;

	wdsx12=wdsx12.Left(wdsx12.GetLength()-2);

	pwdsx41=pwdsx41+atoi(wdsx12);

}
if (jj11==4)
{
	wdxx11=buf;
	
	wdxx11=wdxx11.Left(wdxx11.GetLength()-2);
	pwdxx41=atoi(wdxx11)*10;

}

if (jj11==5)
{
	wdxx12=buf;
	wdxx12=wdxx12.Left(wdxx12.GetLength()-2);

	pwdxx41=pwdxx41+atoi(wdxx12);


}

if (jj11==6)
{
	sdsx11=buf;
	
	sdsx11=sdsx11.Left(sdsx11.GetLength()-2);

	psdsx41=atoi(sdsx11)*10;

}
if (jj11==7)
{
	sdsx12=buf;

	sdsx12=sdsx12.Left(sdsx12.GetLength()-2);

	psdsx41=psdsx41+atoi(sdxx12);

}
if (jj11==8)
{
	sdxx11=buf;
	
	sdxx11=sdxx11.Left(sdxx11.GetLength()-2);

	psdxx41=atoi(sdxx11)*10;

}

if (jj11==9)
{
	sdxx12=buf;
		
	sdxx12=sdxx12.Left(sdxx12.GetLength()-2);

	psdxx41=psdxx41+atoi(sdxx12);
}

	}



		break;
	case 5:

					while (wsdbjFile.ReadString(buf,256))
	{
jj11++;
if (jj11==2)
{
	wdsx11=buf;


	wdsx11=wdsx11.Left(wdsx11.GetLength()-2);

	pwdsx51=atoi(wdsx11)*10;
}
if (jj11==3)
{
	wdsx12=buf;

	wdsx12=wdsx12.Left(wdsx12.GetLength()-2);

	pwdsx51=pwdsx51+atoi(wdsx12);

}
if (jj11==4)
{
	wdxx11=buf;
	
	wdxx11=wdxx11.Left(wdxx11.GetLength()-2);
	pwdxx51=atoi(wdxx11)*10;

}

if (jj11==5)
{
	wdxx12=buf;
	wdxx12=wdxx12.Left(wdxx12.GetLength()-2);

	pwdxx51=pwdxx51+atoi(wdxx12);


}

if (jj11==6)
{
	sdsx11=buf;
	
	sdsx11=sdsx11.Left(sdsx11.GetLength()-2);

	psdsx51=atoi(sdsx11)*10;

}
if (jj11==7)
{
	sdsx12=buf;

	sdsx12=sdsx12.Left(sdsx12.GetLength()-2);

	psdsx51=psdsx51+atoi(sdxx12);

}
if (jj11==8)
{
	sdxx11=buf;
	
	sdxx11=sdxx11.Left(sdxx11.GetLength()-2);

	psdxx51=atoi(sdxx11)*10;

}

if (jj11==9)
{
	sdxx12=buf;
		
	sdxx12=sdxx12.Left(sdxx12.GetLength()-2);

	psdxx51=psdxx51+atoi(sdxx12);
}

	}



		break;
	case 6:

					while (wsdbjFile.ReadString(buf,256))
	{
jj11++;
if (jj11==2)
{
	wdsx11=buf;


	wdsx11=wdsx11.Left(wdsx11.GetLength()-2);

	pwdsx61=atoi(wdsx11)*10;
}
if (jj11==3)
{
	wdsx12=buf;

	wdsx12=wdsx12.Left(wdsx12.GetLength()-2);

	pwdsx61=pwdsx61+atoi(wdsx12);

}
if (jj11==4)
{
	wdxx11=buf;
	
	wdxx11=wdxx11.Left(wdxx11.GetLength()-2);
	pwdxx61=atoi(wdxx11)*10;

}

if (jj11==5)
{
	wdxx12=buf;
	wdxx12=wdxx12.Left(wdxx12.GetLength()-2);

	pwdxx61=pwdxx61+atoi(wdxx12);


}

if (jj11==6)
{
	sdsx11=buf;
	
	sdsx11=sdsx11.Left(sdsx11.GetLength()-2);

	psdsx61=atoi(sdsx11)*10;

}
if (jj11==7)
{
	sdsx12=buf;

	sdsx12=sdsx12.Left(sdsx12.GetLength()-2);

	psdsx61=psdsx61+atoi(sdxx12);

}
if (jj11==8)
{
	sdxx11=buf;
	
	sdxx11=sdxx11.Left(sdxx11.GetLength()-2);

	psdxx61=atoi(sdxx11)*10;

}

if (jj11==9)
{
	sdxx12=buf;
		
	sdxx12=sdxx12.Left(sdxx12.GetLength()-2);

	psdxx61=psdxx61+atoi(sdxx12);
}

	}



		break;


	default:
		break;
	}

	wsdbjFile.Close();


}

void CSuperdhDlg::sendfs11()
{
	unsigned char m_cSBuf[8];

//m_cSBuf[0]=address;

	m_cSBuf[0] =0x01;
  
	m_cSBuf[1] =0x03;

//    m_cSBuf[2] =address;

   m_cSBuf[2] = 0x00;
   
   m_cSBuf[3] =0x2A;

    m_cSBuf[4] =0x00;

    m_cSBuf[5] =0x01;

CRC16(m_cSBuf,6);
	//=========deal crc  
    m_cSBuf[6] =CRCHi;
    m_cSBuf[7] =CRCLo;

	m_comm1.WriteCom(m_cSBuf,8);
   
	fsfxseq=1;

}

void CSuperdhDlg::F_IniTreeall()
{
//	m_treeall.DeleteAllItems();
	HTREEITEM node1,node2,node3;
	int i,j,k,iNum;
	CString sTemp;
	m_kswtp11.DeleteAllItems();

	//sTemp.Format("%s", serverinfo[i].m_csServerName);
   i=0;
	sTemp="�������";

			node1=m_kswtp11.InsertItem(sTemp,0,0,TVI_ROOT);
			m_kswtp11.SetItemData(node1,i);

	sTemp="���ٷ���";
j=0;
			node2=m_kswtp11.InsertItem(sTemp,0,0,node1);
			m_kswtp11.SetItemData(node2,j);

	sTemp="����";
k=0;
			node3=m_kswtp11.InsertItem(sTemp,0,0,node2);
			m_kswtp11.SetItemData(node3,k);

	sTemp="����";
k=1;
			node3=m_kswtp11.InsertItem(sTemp,0,0,node2);
			m_kswtp11.SetItemData(node3,k);

//===================2 ========================
				sTemp="��ʪ��";
j=1;
			node2=m_kswtp11.InsertItem(sTemp,0,0,node1);
			m_kswtp11.SetItemData(node2,j);

	sTemp="�����豸��1";
k=0;
			node3=m_kswtp11.InsertItem(sTemp,0,0,node2);
			m_kswtp11.SetItemData(node3,k);

	sTemp="�����豸��2";
k=1;
			node3=m_kswtp11.InsertItem(sTemp,0,0,node2);
			m_kswtp11.SetItemData(node3,k);

	sTemp="�����豸��3";
k=2;
			node3=m_kswtp11.InsertItem(sTemp,0,0,node2);
			m_kswtp11.SetItemData(node3,k);

	sTemp="35KV������1";
k=3;
			node3=m_kswtp11.InsertItem(sTemp,0,0,node2);
			m_kswtp11.SetItemData(node3,k);
	sTemp="35KV������2";
k=4;
			node3=m_kswtp11.InsertItem(sTemp,0,0,node2);
			m_kswtp11.SetItemData(node3,k);

	sTemp="35KV������3";
k=5;
			node3=m_kswtp11.InsertItem(sTemp,0,0,node2);
			m_kswtp11.SetItemData(node3,k);

m_kswtp11.Expand(node1,TVE_EXPAND);
m_kswtp11.Expand(node2,TVE_EXPAND);
}

void CSuperdhDlg::OnDblclkTreeKxw11(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
		HTREEITEM node1,node2,node3;
	int i,j;
	CString sTemp;
	
	node1=m_kswtp11.GetSelectedItem();
	if(node1==NULL)
	{
		return;
	}
	node2=m_kswtp11.GetParentItem(node1);
	if(node2==NULL)
	{
	
	}
	else
	{
		i=m_kswtp11.GetItemData(node2);
		j=m_kswtp11.GetItemData(node1);

        if((i==0) && (j==0)) sendfs11();
		 if((i==0) && (j==1)) sendfx11();

         if((i==1) && (j==0)) ggsendwsd(11);
		 if((i==1) && (j==1)) ggsendwsd(12);

	     if((i==1) && (j==2)) ggsendwsd(13);
		 if((i==1) && (j==3)) ggsendwsd(14);

         if((i==1) && (j==4)) ggsendwsd(15);
		 if((i==1) && (j==5)) ggsendwsd(16);


	//	ChannelInfoDlg.m_iServerNum = i;
	//	ChannelInfoDlg.m_iChannelNum = j;
	//	ChannelInfoDlg.DoModal();
	//	m_treeall.SetItemText(node1,allipinfo[i][j].m_csChanName);
	}


	*pResult = 0;
}

void CSuperdhDlg::TScan12()
{

if (fsfxsctl==0) 
{
	fsfxsctl = 1;

sendfs11();
return;
}

if (fsfxsctl==1) 
{
	fsfxsctl = 0;

sendfx11();
return;
}


}

void CSuperdhDlg::KSaveFile()
{
	CTime time = CTime::GetCurrentTime();
	CString strTime = time.Format(_T("\\%Y%m%d%H%M%S.log"));
	char dir[MAX_PATH];
	memset(dir,0,sizeof(0));
	if(GetCurrentDirectory(sizeof(dir),dir))
	{
		strcat(dir,"\\Log");

		WIN32_FIND_DATA fd;
		HANDLE hFind = FindFirstFile(dir,&fd);
		if((hFind == INVALID_HANDLE_VALUE) ||(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)))
		{
			SECURITY_ATTRIBUTES attributes;
			attributes.nLength = sizeof(SECURITY_ATTRIBUTES);
			attributes.lpSecurityDescriptor = NULL;
			attributes.bInheritHandle = TRUE;
			CreateDirectory(dir,&attributes);
		}

		strcat(dir,strTime);

  //   AfxMessageBox(dir);



	}

}

void CSuperdhDlg::KtkOpenFile()
{
	CTime time = CTime::GetCurrentTime();
    
	CString strpFile11,strpFile12,strpFile13;

	CString strTime = time.Format(_T("\\%Y%m%d"));
	char dir[MAX_PATH];
	memset(dir,0,sizeof(0));
	if(GetCurrentDirectory(sizeof(dir),dir))
	{
		strcat(dir,"\\Log");

		WIN32_FIND_DATA fd;
		HANDLE hFind = FindFirstFile(dir,&fd);
		if((hFind == INVALID_HANDLE_VALUE) ||(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)))
		{
			SECURITY_ATTRIBUTES attributes;
			attributes.nLength = sizeof(SECURITY_ATTRIBUTES);
			attributes.lpSecurityDescriptor = NULL;
			attributes.bInheritHandle = TRUE;
			CreateDirectory(dir,&attributes);
		}

		strcat(dir,strTime);

    // AfxMessageBox(dir);

	}

  strpFile11.Format("%srec.dat", dir);

  strpFile13.Format("%sfxrec.dat", dir);
 
  //  AfxMessageBox(strpFile11);

   strpFile12.Format("%salm.dat", dir);

  // AfxMessageBox(strpFile12);
  // AfxMessageBox(strpFile13);

 //  /*
 if (sunrec11.Open(strpFile11,CFile::modeCreate|CFile::modeWrite|CFile::modeNoTruncate) == FALSE)
		{ 
		    AfxMessageBox("create sunrecfile error");
	//	    return;
		}

 if (sunrec12.Open(strpFile13,CFile::modeCreate|CFile::modeWrite|CFile::modeNoTruncate) == FALSE)
		{ 
		    AfxMessageBox("create fsfxfile error");
	//	    return;
		}
 if (sunalarm11.Open(strpFile12,CFile::modeCreate|CFile::modeWrite|CFile::modeNoTruncate) == FALSE)
		{ 
		    AfxMessageBox("create sunarmfile error");
	//	    return;
		}
//*/
//sunrec11.WriteString("abcd\r\n");
//sunalarm11.WriteString("papa\r\n");

}

void CSuperdhDlg::KdtOpenFile()
{
	CTime zktime;
		zktime = CTime::GetCurrentTime();
		if((zktime.GetHour() == 23)&&(zktime.GetMinute() == 59)&&(zktime.GetSecond() == 58))
		{
	bkctlf11=1;
		sunrec11.Close();
			sunrec12.Close();
sunalarm11.Close();
dkfilect11=1;
wsdrec11="";
walarmrec11="";
		}

		if (dkfilect11>0) dkfilect11++;
	if (dkfilect11>10) 
	{
        KtkOpenFile();
		dkfilect11=0;
	bkctlf11=0;
ZxydelFile();

    }
}

void CSuperdhDlg::zkpiniRR11()
{

	jkparea[0]="����";
    jkparea[1]="����";

    jkparea[2]="�����豸��1";
    jkparea[3]="�����豸��2";

	jkparea[4]="�����豸��3";
    jkparea[5]="35KV������1";

    jkparea[6]="35KV������2";
    jkparea[7]="35KV������3";

    jkparea[8]="��ʪ��7";
    jkparea[9]="��ʪ��8";

}

void CSuperdhDlg::OnHisdata() 
{
	// TODO: Add your command handler code here
	CHisInq  hisdlg;
       
	hisdlg.DoModal();


}

void CSuperdhDlg::StxTime()
{

	CWnd *pWnd;


	pWnd= (CWnd*)GetDlgItem(IDC_STATIC_TIME);
	
		if(pWnd)
	{
//		pWnd->SetWindowPos(NULL,ScreenRect.right-3*ScreenRect.right/20,ScreenRect.top+10,0,0,
//			SWP_NOSIZE|SWP_NOZORDER | SWP_NOACTIVATE);
	
				pWnd->SetWindowPos(NULL,960,168,0,0,
			SWP_NOSIZE|SWP_NOZORDER | SWP_NOACTIVATE);

		}

}

HBRUSH CSuperdhDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
	if(IDC_STATIC_TIME == pWnd->GetDlgCtrlID())
	{
		pDC->SelectObject(&m_fontText);
		pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(0,0,132));
	//	return m_hBrushBK;
	}
	
	// TODO: Return a different brush if the default is not desired
	return hbr;
}

void CSuperdhDlg::OnAlarmdata() 
{
	// TODO: Add your command handler code here
	CHisAlarm  Almdlg;
       
	Almdlg.DoModal();

}

void CSuperdhDlg::ZxydelFile()
{

CTime dftime = CTime::GetCurrentTime();
    
	CString strpFile11,strpFile12,strpFile13;

	CString strTime = dftime.Format(_T("%m%d"));
	CString YefTime11,YefTime12,YefTime13,YefTime14,YefTime15;

	char dir[MAX_PATH];
	memset(dir,0,sizeof(0));

	if(GetCurrentDirectory(sizeof(dir),dir))
	{
		strcat(dir,"\\Log\\");

	}

YefTime11.Format("%04d",dftime.GetYear());

//strpFile11.Format("%srec.dat", dir);
YefTime12.Format("%04d",atoi(YefTime11)-1);
YefTime13.Format("%s%s%srec.dat",dir,YefTime12,strTime);
YefTime14.Format("%s%s%sfxrec.dat",dir,YefTime12,strTime);
YefTime15.Format("%s%s%salm.dat",dir,YefTime12,strTime);

//AfxMessageBox(YefTime11);
//AfxMessageBox(YefTime13);
 DeleteFile(YefTime13);
DeleteFile(YefTime14);
DeleteFile(YefTime15);



}
