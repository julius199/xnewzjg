// HisAlarm.cpp : implementation file
//

#include "stdafx.h"
#include "superdh.h"
#include "HisAlarm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHisAlarm dialog


CHisAlarm::CHisAlarm(CWnd* pParent /*=NULL*/)
	: CDialog(CHisAlarm::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHisAlarm)
	m_btkdate = COleDateTime::GetCurrentTime();
	//}}AFX_DATA_INIT
}


void CHisAlarm::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHisAlarm)
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER1, m_btkdate);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHisAlarm, CDialog)
	//{{AFX_MSG_MAP(CHisAlarm)
	ON_BN_CLICKED(IDC_BUT_BJJL, OnButBjjl)
	ON_BN_CLICKED(IDC_BUT_MKDATA, OnButMkdata)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHisAlarm message handlers

BOOL CHisAlarm::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
		kf11=0;
	   kf12=1;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CHisAlarm::OnButBjjl() 
{
	// TODO: Add your control notification handler code here
			CString strpFile11,strpFile12,strpFile13,xFilent11;
		
//		CStdioFile wsdbjFile;
	    char cfWorkDir[256];
        char swbuf[256];

		UpdateData(TRUE);
//	CTime time = CTime::GetCurrentTime();
 	SetDlgItemText(IDC_EDIT_HISALARM,"");
//	CString strTime = m_ctHisDate.Format(_T("\\%Y%m%d"));
        xFilent11=_T("");

		GetCurrentDirectory(256, cfWorkDir);

	strpFile11.Format("%s\\log\\%04d%02d%02dalm.dat", cfWorkDir,m_btkdate.GetYear(), m_btkdate.GetMonth(), m_btkdate.GetDay());

 // AfxMessageBox(strpFile11);

if (wsdbjFile.Open(strpFile11, CFile::modeRead) == FALSE)
	{
	 AfxMessageBox("����������ʷ��¼������ѡ����Ϊϵͳ���еĵ�������!");
		return;
	}

 long jj11=0;

//	while (wsdbjFile.ReadString(swbuf,256))

	while ((wsdbjFile.ReadString(swbuf,256)) && (kf11<5000))

	{
   
		wdsd11=swbuf;
       wdsd12=wdsd12+wdsd11;
    

  kf11++;

	}
 // AfxMessageBox(strTime);
if (kf11<1)
{
AfxMessageBox("��������ʷ��¼Ϊ�ռ�¼");
wsdbjFile.Close();
return;
}
else
{
	SetDlgItemText(IDC_EDIT_HISALARM,wdsd12);
GetDlgItem(IDC_BUT_MKDATA)->EnableWindow(TRUE);

}


}

void CHisAlarm::amdisplay(int uu11)
{

char swbuf[256];
int qf11=0;

	while ((wsdbjFile.ReadString(swbuf,256)) && (kf11<5000*uu11))

	{
   
		wdsd11=swbuf;
       wdsd12=wdsd12+wdsd11;
    

  kf11++;
   qf11++;
	}

	SetDlgItemText(IDC_EDIT_HISALARM,wdsd12);

 if (qf11==0) 
 {
wsdbjFile.Close();

	 AfxMessageBox("ע�⣬������ȫ����ʾ");
	GetDlgItem(IDC_BUT_BJJL)->EnableWindow(TRUE);
	

 }
 else
 {
	AfxMessageBox("ע�⣬ÿ��һ�δ˼�������ʾ5000����¼��ֱ������ȫ����ʾ");
 }

}

void CHisAlarm::OnButMkdata() 
{
	// TODO: Add your control notification handler code here
		GetDlgItem(IDC_BUT_BJJL)->EnableWindow(FALSE);
	

kf12++;
amdisplay(kf12);

}
