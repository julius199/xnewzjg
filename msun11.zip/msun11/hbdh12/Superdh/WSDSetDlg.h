#if !defined(AFX_WSDSETDLG_H__39B60A84_77F8_4A2C_A322_E4BF90DB5F77__INCLUDED_)
#define AFX_WSDSETDLG_H__39B60A84_77F8_4A2C_A322_E4BF90DB5F77__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WSDSetDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWSDSetDlg dialog

class CWSDSetDlg : public CDialog
{
// Construction
public:
	int ctlkdg11;
	int jkpoint;
	int pwdxx11;
	int pwdsx11;
	int pwdxx21;
	int pwdsx21;
    int pwdxx31;
	int pwdsx31;
	int pwdxx41;
	int pwdsx41;
    int pwdxx51;
	int pwdsx51;
	int pwdxx61;
	int pwdsx61;

	int psdxx11;
	int psdsx11;
	int psdxx21;
	int psdsx21;
    int psdxx31;
	int psdsx31;
	int psdxx41;
	int psdsx41;
    int psdxx51;
	int psdsx51;
	int psdxx61;
	int psdsx61;

	CWSDSetDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CWSDSetDlg)
	enum { IDD = IDD_DLG_WSDSET };
	CComboBox	m_jkpoint;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWSDSetDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWSDSetDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButSave();
	afx_msg void OnButCall();
	afx_msg void OnSelchangeComJkpoint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WSDSETDLG_H__39B60A84_77F8_4A2C_A322_E4BF90DB5F77__INCLUDED_)
